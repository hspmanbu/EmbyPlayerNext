package com.aistudio.embyplayer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.aistudio.embyplayer.data.model.*
import com.aistudio.embyplayer.ui.components.MediaCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    item: EmbyItem?,
    seasons: List<EmbyItem>,
    selectedSeasonId: String?,
    episodes: List<EmbyItem>,
    loading: Boolean,
    selectedPerson: EmbyPerson?,
    personWorks: List<EmbyItem>,
    imageFor: (EmbyItem, String) -> String?,
    onBack: () -> Unit,
    onPlay: (Boolean) -> Unit,
    onFavorite: () -> Unit,
    onPlayed: () -> Unit,
    onDelete: () -> Unit,
    onSeason: (EmbyItem) -> Unit,
    onEpisode: (EmbyItem) -> Unit,
    onPerson: (EmbyPerson) -> Unit,
    onClosePerson: () -> Unit,
) {
    if (item == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        return
    }

    var deleteConfirm by remember(item.id) { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "返回") } },
            )
        },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            item {
                DetailHero(item, loading, imageFor)
                DetailHeader(item, imageFor)
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    if (item.isPlayable) {
                        PlaybackActions(item, onPlay)
                    }

                    Row(
                        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        AssistChip(
                            onClick = onFavorite,
                            label = { Text(if (item.userData.isFavorite) "已收藏" else "收藏") },
                            leadingIcon = {
                                Icon(if (item.userData.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
                            },
                        )
                        AssistChip(
                            onClick = onPlayed,
                            label = { Text(if (item.isPlayed) "标记未看" else "标记已看") },
                            leadingIcon = { Icon(Icons.Default.CheckCircle, null) },
                        )
                        AssistChip(
                            onClick = { deleteConfirm = true },
                            label = { Text("删除") },
                            leadingIcon = { Icon(Icons.Default.Delete, null) },
                        )
                    }

                    if (item.genres.isNotEmpty()) {
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(7.dp),
                        ) {
                            item.genres.forEach { genre -> SuggestionChip(onClick = {}, label = { Text(genre) }) }
                        }
                    }

                    item.overview?.takeIf { it.isNotBlank() }?.let { overview ->
                        InfoPanel("剧情简介") {
                            Text(
                                overview,
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }

                    val video = item.mediaStreams.firstOrNull { it.type.equals("Video", true) }
                    val audio = item.mediaStreams.firstOrNull { it.type.equals("Audio", true) }
                    if (item.mediaStreams.isNotEmpty() || item.path != null) {
                        InfoPanel("媒体信息") {
                            Text(
                                listOfNotNull(
                                    video?.codec?.uppercase(),
                                    if (item.width != null && item.height != null) "${item.width}×${item.height}" else null,
                                    audio?.displayTitle ?: audio?.codec?.uppercase(),
                                ).joinToString(" · ").ifBlank { item.type },
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            item.path?.let { path ->
                                Text(
                                    path,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                )
                            }
                        }
                    }
                }
            }

            if (item.people.isNotEmpty()) {
                item { SectionHeader("演职人员", "点击查看作品") }
                item {
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 18.dp),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        items(item.people.take(30), key = { it.id + it.name + (it.role ?: "") }) { person ->
                            ElevatedCard(
                                onClick = { onPerson(person) },
                                modifier = Modifier.width(158.dp),
                                shape = RoundedCornerShape(18.dp),
                            ) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(Icons.Default.Person, null, tint = MaterialTheme.colorScheme.primary)
                                    Text(person.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        person.role ?: person.type.orEmpty(),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (seasons.isNotEmpty()) {
                item { SectionHeader("剧集", "${episodes.size} 集") }
                item {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        seasons.forEach { season ->
                            FilterChip(
                                selected = season.id == selectedSeasonId,
                                onClick = { onSeason(season) },
                                label = { Text(season.name) },
                            )
                        }
                    }
                }
                items(episodes, key = { it.id }) { episode ->
                    EpisodeRow(episode, imageFor(episode, "Primary")) { onEpisode(episode) }
                }
            }
        }
    }

    if (deleteConfirm) {
        AlertDialog(
            onDismissRequest = { deleteConfirm = false },
            title = { Text("删除媒体") },
            text = { Text("确定要从服务器删除《${item.name}》吗？\n\n这可能同时删除对应的媒体文件，且无法撤销。") },
            confirmButton = {
                Button(onClick = { deleteConfirm = false; onDelete() }) { Text("删除") }
            },
            dismissButton = { TextButton(onClick = { deleteConfirm = false }) { Text("取消") } },
        )
    }

    if (selectedPerson != null) {
        ModalBottomSheet(onDismissRequest = onClosePerson) {
            Text(
                "${selectedPerson.name} 的作品",
                Modifier.padding(horizontal = 18.dp, vertical = 8.dp),
                style = MaterialTheme.typography.titleLarge,
            )
            if (personWorks.isEmpty()) {
                Text("暂无作品", Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                LazyRow(
                    contentPadding = PaddingValues(18.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    items(personWorks, key = { it.id }) { work ->
                        MediaCard(work, imageFor(work, "Primary"), { onEpisode(work) }, Modifier.width(150.dp))
                    }
                }
            }
            Spacer(Modifier.height(26.dp))
        }
    }
}

@Composable
private fun DetailHero(item: EmbyItem, loading: Boolean, imageFor: (EmbyItem, String) -> String?) {
    Box(Modifier.fillMaxWidth().aspectRatio(16f / 8.2f).background(MaterialTheme.colorScheme.surfaceVariant)) {
        (imageFor(item, "Backdrop") ?: imageFor(item, "Primary"))?.let { image ->
            AsyncImage(image, item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(Color.Transparent, Color.Black.copy(alpha = .18f), MaterialTheme.colorScheme.background),
                ),
            ),
        )
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.BottomCenter))
    }
}

@Composable
private fun DetailHeader(item: EmbyItem, imageFor: (EmbyItem, String) -> String?) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp).offset(y = (-34).dp),
        verticalAlignment = Alignment.Bottom,
    ) {
        Surface(
            modifier = Modifier.width(116.dp).aspectRatio(2f / 3f),
            shape = RoundedCornerShape(18.dp),
            tonalElevation = 6.dp,
            shadowElevation = 6.dp,
        ) {
            val poster = imageFor(item, "Primary")
            if (poster != null) {
                AsyncImage(poster, item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                Box(
                    Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceContainerHigh),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Default.Movie, null, Modifier.size(40.dp)) }
            }
        }
        Spacer(Modifier.width(16.dp))
        Column(Modifier.weight(1f).padding(bottom = 4.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(item.name, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, maxLines = 2)
            val meta = listOfNotNull(
                item.productionYear?.toString(),
                item.officialRating,
                item.communityRating?.let { "★ %.1f".format(it) },
                item.durationMs.takeIf { it > 0 }?.let { "${it / 60_000} 分钟" },
            )
            if (meta.isNotEmpty()) Text(meta.joinToString(" · "), color = MaterialTheme.colorScheme.onSurfaceVariant)
            item.tagline?.takeIf { it.isNotBlank() }?.let {
                Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
private fun PlaybackActions(item: EmbyItem, onPlay: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (item.resumePositionMs > 0 && !item.isPlayed) {
            Button(onClick = { onPlay(true) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text("继续播放")
            }
            FilledTonalButton(onClick = { onPlay(false) }) { Text("从头") }
        } else {
            Button(onClick = { onPlay(false) }, modifier = Modifier.weight(1f)) {
                Icon(Icons.Default.PlayArrow, null)
                Spacer(Modifier.width(6.dp))
                Text("立即播放")
            }
        }
    }
}

@Composable
private fun InfoPanel(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            content()
        }
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun EpisodeRow(item: EmbyItem, imageUrl: String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.width(138.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
        ) {
            if (imageUrl != null) AsyncImage(imageUrl, item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Icon(Icons.Default.PlayCircle, null, Modifier.align(Alignment.Center).size(34.dp), tint = Color.White.copy(alpha = .9f))
            val progress = item.userData.playedPercentage?.toFloat()?.div(100f)
                ?: if (item.runTimeTicks != null && item.runTimeTicks > 0) {
                    (item.userData.playbackPositionTicks.toDouble() / item.runTimeTicks).toFloat()
                } else 0f
            if (progress > 0f && progress < 1f) {
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(3.dp).align(Alignment.BottomCenter),
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(
                listOfNotNull(
                    item.parentIndexNumber?.let { "S$it" },
                    item.indexNumber?.let { "E$it" },
                    item.durationMs.takeIf { it > 0 }?.let { "${it / 60_000} 分钟" },
                ).joinToString(" · "),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (item.isPlayed) Icon(Icons.Default.CheckCircle, "已看", tint = MaterialTheme.colorScheme.primary)
    }
}
