package com.aistudio.embyplayer.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import com.aistudio.embyplayer.data.model.EmbyServerConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    config: EmbyServerConfig,
    onUpdate: (EmbyServerConfig) -> Unit,
    onDynamic: () -> Unit,
    onLogin: () -> Unit,
    onLogout: () -> Unit,
    onShareLog: () -> Unit,
    onClearLog: () -> Unit,
    onBack: () -> Unit,
) {
    var logoutConfirm by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("设置")
                        Text("播放、显示与服务器", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "返回") } },
            )
        },
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp),
        ) {
            item {
                SettingSection("账号与服务器", Icons.Default.Dns) {
                    SettingRow(
                        title = config.serverName.ifBlank { "Emby Server" },
                        subtitle = config.serverUrl.ifBlank { "尚未配置服务器" },
                        icon = Icons.Default.Storage,
                        onClick = onLogin,
                    )
                    HorizontalDivider()
                    SettingRow(
                        title = if (config.accessToken.isBlank()) "登录服务器" else "切换服务器 / 重新登录",
                        subtitle = config.username.ifBlank { "当前未登录" },
                        icon = Icons.Default.Login,
                        onClick = onLogin,
                    )
                    HorizontalDivider()
                    SettingRow(
                        title = "动态端口",
                        subtitle = if (config.dynamicPortEnabled) "已启用 · ${config.dynamicPortTargetDomain}" else "未启用",
                        icon = Icons.Default.SettingsEthernet,
                        onClick = onDynamic,
                    )
                    if (config.accessToken.isNotBlank()) {
                        HorizontalDivider()
                        SettingRow(
                            title = "退出登录",
                            subtitle = "清除当前服务器登录 Token",
                            icon = Icons.Default.Logout,
                            onClick = { logoutConfirm = true },
                        )
                    }
                }
            }

            item {
                SettingSection("界面", Icons.Default.Tune) {
                    Column(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("界面缩放", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "根据手机、平板或车机屏幕调整信息密度。当前 ${(config.uiScale * 100).toInt()}%",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        ChoiceChips(
                            options = listOf(
                                .85f to "85%",
                                1f to "100%",
                                1.15f to "115%",
                                1.25f to "125%",
                                1.4f to "140%",
                                1.6f to "160%",
                            ),
                            selected = config.uiScale,
                        ) { onUpdate(config.copy(uiScale = it)) }
                    }
                }
            }

            item {
                SettingSection("播放与解码", Icons.Default.PlayCircle) {
                    SwitchRow(
                        "硬件加速解码",
                        "优先使用设备 MediaCodec，适用于 H.264 / HEVC / AV1 等格式",
                        config.hardwareDecoding,
                    ) { onUpdate(config.copy(hardwareDecoding = it)) }
                    HorizontalDivider()
                    IntChoice(
                        title = "后退步长",
                        current = config.rewindSeconds,
                        options = listOf(5, 10, 15, 20, 30, 45, 60, 90),
                        suffix = { "$it 秒" },
                    ) { onUpdate(config.copy(rewindSeconds = it)) }
                    HorizontalDivider()
                    IntChoice(
                        title = "前进步长",
                        current = config.forwardSeconds,
                        options = listOf(5, 10, 15, 20, 30, 45, 60, 90),
                        suffix = { "$it 秒" },
                    ) { onUpdate(config.copy(forwardSeconds = it)) }
                    HorizontalDivider()
                    IntChoice(
                        title = "全屏手势快进跨度",
                        current = config.gestureSeekSeconds,
                        options = listOf(60, 120, 180, 300, 600),
                        suffix = { value -> if (value < 60) "$value 秒" else "${value / 60} 分钟" },
                    ) { onUpdate(config.copy(gestureSeekSeconds = it)) }
                    HorizontalDivider()
                    IntChoice(
                        title = "本地磁盘缓冲",
                        current = config.cacheMb,
                        options = listOf(0, 64, 128, 256, 512),
                        suffix = { if (it == 0) "关闭" else "$it MB" },
                    ) { onUpdate(config.copy(cacheMb = it)) }
                }
            }

            item {
                SettingSection("网络与兼容性", Icons.Default.NetworkCheck) {
                    SwitchRow(
                        "允许自签名 HTTPS",
                        "仅在你明确使用家庭自签名证书时开启",
                        config.allowInsecureHttps,
                    ) { onUpdate(config.copy(allowInsecureHttps = it)) }
                }
            }

            item {
                SettingSection("诊断与关于", Icons.Default.Info) {
                    SettingRow("导出诊断日志", "直接分享 emby_diag.txt，便于排查网络和播放问题", Icons.Default.Share, onShareLog)
                    HorizontalDivider()
                    SettingRow("清除诊断日志", "清空本机当前诊断文件", Icons.Default.DeleteSweep, onClearLog)
                    HorizontalDivider()
                    ListItem(
                        headlineContent = { Text("EmbyPlayerNext 2.2.0") },
                        supportingContent = { Text("媒体库重构 · 全局搜索 · 分页浏览 · 自适应媒体卡片 · 播放体验优化") },
                        leadingContent = { Icon(Icons.Default.Info, null) },
                    )
                }
            }

            item { Spacer(Modifier.height(20.dp)) }
        }
    }

    if (logoutConfirm) {
        AlertDialog(
            onDismissRequest = { logoutConfirm = false },
            title = { Text("确认退出登录？") },
            text = { Text("退出后将清除登录 Token，下次使用需要重新登录服务器。") },
            confirmButton = {
                Button(onClick = { logoutConfirm = false; onLogout() }) { Text("退出") }
            },
            dismissButton = { TextButton(onClick = { logoutConfirm = false }) { Text("取消") } },
        )
    }
}

@Composable
private fun SettingSection(title: String, icon: ImageVector, content: @Composable ColumnScope.() -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Text(title, style = MaterialTheme.typography.titleLarge)
        }
        Surface(
            shape = RoundedCornerShape(22.dp),
            color = MaterialTheme.colorScheme.surfaceContainer,
            content = { Column(content = content) },
        )
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, icon: ImageVector, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        leadingContent = { Icon(icon, null) },
        trailingContent = { Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) },
        colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
        modifier = Modifier.clickable(onClick = onClick),
    )
}

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = { Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        trailingContent = { Switch(checked = checked, onCheckedChange = onChecked) },
        colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    )
}

@Composable
private fun <T> ChoiceChips(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { (value, label) ->
            FilterChip(selected = value == selected, onClick = { onSelect(value) }, label = { Text(label) })
        }
    }
}

@Composable
private fun IntChoice(
    title: String,
    current: Int,
    options: List<Int>,
    suffix: (Int) -> String = { it.toString() },
    onSelect: (Int) -> Unit,
) {
    var open by remember { mutableStateOf(false) }
    Box {
        ListItem(
            headlineContent = { Text(title) },
            supportingContent = { Text(suffix(current), color = MaterialTheme.colorScheme.onSurfaceVariant) },
            trailingContent = { Icon(Icons.Default.ExpandMore, null) },
            colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
            modifier = Modifier.clickable { open = true },
        )
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { value ->
                DropdownMenuItem(
                    text = { Text(suffix(value)) },
                    onClick = { open = false; onSelect(value) },
                    trailingIcon = {
                        if (value == current) Icon(Icons.Default.Check, null, tint = MaterialTheme.colorScheme.primary)
                    },
                )
            }
        }
    }
}
